import * as cdk from 'aws-cdk-lib';
import { AppInfo } from "./appInfo";
import { Construct } from 'constructs';
import {SecurityGroup, Vpc} from "aws-cdk-lib/aws-ec2";
import {StringParameter} from "aws-cdk-lib/aws-ssm";


export class ResttodoappStack extends Construct {
  constructor(scope: Construct, id: string, props?: AppInfo) {
    super(scope, id, props);


//

      // Create a new VPC
      const vpc = new Vpc(this, 'MyVPC', {
          maxAzs: 3,  // Default is all available AZs
          natGateways: 1,  // Number of NAT gateways
      });

      // Example: Create a security group in the VPC
      const securityGroup = new SecurityGroup(this, 'MySecurityGroup', {
          vpc,
          allowAllOutbound: true,
          description: 'Security group for my resources',
      });

    new StringParameter(this,"",{stringValue: vpc.vpcId,parameterName:"vpcid"})
      new StringParameter(this,"",{stringValue: vpc.vpcArn,parameterName:"vpcArn"})
      new StringParameter(this,"",{stringValue: securityGroup.securityGroupId,parameterName:"securityGroupId"})

  }
}
