import * as cdk from 'aws-cdk-lib';
import { AppInfo } from "./appInfo";
import { Construct } from 'constructs';
import {AttributeType, BillingMode, Table} from "aws-cdk-lib/aws-dynamodb";
import {RemovalPolicy} from "aws-cdk-lib";
import {StringParameter} from "aws-cdk-lib/aws-ssm";
// import * as sqs from 'aws-cdk-lib/aws-sqs';

export class DatabaseStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props?: AppInfo) {
    super(scope, id, props);

       function selectRemovePolicy (props?:AppInfo) {
           if (props?.envName == "prod") return  RemovalPolicy.RETAIN
       else return RemovalPolicy.DESTROY
       }

        // Define the DynamoDB table
      const table = new Table(this, 'TasksTable',
          {
              tableName: 'TasksTable'+ props?.envName,
              partitionKey: { name: 'taskId', type: AttributeType.STRING },
              sortKey: { name: 'task', type: AttributeType.STRING }, // Optional: use as sort key if tasks need ordering
              billingMode: BillingMode.PAY_PER_REQUEST, // PAY_PER_REQUEST or PROVISIONED
              removalPolicy: selectRemovePolicy(props), // Removes the table when stack is deleted
      });

      // Optional: Add a Global Secondary Index (GSI)
      table.addGlobalSecondaryIndex({
          indexName: 'TaskIndex',
          partitionKey: { name: 'task', type: AttributeType.STRING },
          sortKey: { name: 'taskId', type: AttributeType.STRING },
      });

      new StringParameter(this,"",{parameterName: "mainTable_"+ props?.envName,stringValue:table.tableArn})

  }
}
