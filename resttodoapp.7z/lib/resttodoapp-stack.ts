import * as cdk from 'aws-cdk-lib';
import { AppInfo } from "./appInfo";
import { Construct } from 'constructs';
import {NodejsFunction} from "aws-cdk-lib/aws-lambda-nodejs";
import {Runtime} from "node:inspector";
import {Table} from "aws-cdk-lib/aws-dynamodb";
import {StringParameter} from "aws-cdk-lib/aws-ssm";
// import * as sqs from 'aws-cdk-lib/aws-sqs';

export class ResttodoappStack extends Construct {
  constructor(scope: Construct, id: string, props?: AppInfo) {
      super(scope, id, props);


    const table = Table.fromTableArn(this,"",
        StringParameter.fromStringParameterName(this,"SS",
        "mainTable_"+ props?.envName).stringValue)

// Create the Lambda function
      const myFunction = new NodejsFunction(this, 'MyFunction', {
          entry: 'lambda/my-function.ts', // entry point to your Lambda function
          handler: 'handler', // the name of the exported handler in the entry file
          runtime:  cdk.aws_lambda.Runtime.NODEJS_20_X, // or another supported Node.js runtime
          environment: {
              TABLE_NAME: table.tableName,
          },
      });

      // Grant the Lambda function read/write permissions on the DynamoDB table
      table.grantReadWriteData(myFunction);
    
  }
}
